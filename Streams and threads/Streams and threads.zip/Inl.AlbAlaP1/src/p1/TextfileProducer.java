/**
 @author Alameer Albadrani
 Datateknik
 */



package p1;


import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class TextfileProducer implements p1.MessageProducer
{

    private p1.Message[] messages;
    // private String filename;
    private int delay;
    private int times;
    private int size;
    private Buffer buffer = new Buffer();
    private int currentIndex = -1;


    /**
     *
     * @param filename
     * @throws IOException
     *
     * The class will set how many times the message will be repeated, how long time each one will take and
     * the size of our message
     */
    public TextfileProducer (String filename) throws IOException{
        BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(filename), StandardCharsets.UTF_8));
        this.times = Integer.parseInt(input.readLine());
        this.delay = Integer.parseInt(input.readLine());
        this.size = Integer.parseInt(input.readLine());
        this.currentIndex =0;
        this.messages = new Message[this.size];

        for(int i = 0; i < size; ++i)
        {
            messages[i] = new Message(input.readLine(), new ImageIcon(input.readLine()));
        }
        input.close();
    }

    /**
     * a first try with this class which has failed
     *
     * @return
     */


    @Override
    public int delay() {
        return delay;
    }

    @Override
    public int times() {
        return times;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public Message nextMessage() {
        if(size()==0)
            return null;
        currentIndex = (currentIndex+1) % this.size;
        return messages[currentIndex];
    }

}
