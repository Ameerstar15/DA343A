package p1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectfileProducer implements p1.MessageProducer
{

    private int delay;
    private int times;
    private int size;
    private p1.Message[] messages;
    private int currentIndex = -1;

    public ObjectfileProducer(String filename) throws IOException {
        ObjectInputStream ois = null;

        try
        {
            ois = new ObjectInputStream(new FileInputStream(filename));
            this.times = ois.readInt();
            this.delay = ois.readInt();
            this.size = ois.readInt();
            this.messages = new p1.Message[this.size];

            for(int i =0; i < this.size; i++)
            {
                this.messages[i] = (p1.Message)ois.readObject();
            }
        } catch (Exception e ){
            e.printStackTrace();
        } finally {
            ois.close();
        }
    }


    public int delay() {
        return this.delay;
    }

    public int times() {
        return this.times;
    }


    public int size() {
        return this.size;
    }

    public p1.Message nextMessage() {
        if (this.size == 0) {
            return null;
        } else {
            this.currentIndex = (this.currentIndex + 1) % this.size;
            return this.messages[this.currentIndex];
        }
    }
}
