//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package p1;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class MessageManager extends Thread {
    private Buffer<Message> messageBuffer;
    private Message m;
    private final PropertyChangeSupport change = new PropertyChangeSupport(this);

    public MessageManager(Buffer<Message> messageBuffer) {
        this.messageBuffer = messageBuffer;
        this.m = null;
    }

    public void run() {
        while(!interrupted()) {
            try {
                m = messageBuffer.get();
                change.firePropertyChange("message", (Object)null, m);

            } catch (InterruptedException var2) {
                var2.printStackTrace();
            }
        }

    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        this.change.addPropertyChangeListener(listener);
    }
}
