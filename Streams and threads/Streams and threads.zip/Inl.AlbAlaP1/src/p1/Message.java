package p1;

import javax.swing.*;

public class Message
{
    private String text;
    private Icon icon;

    public Message(String text, Icon icon)
    {
        this.icon = icon;
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }
}
