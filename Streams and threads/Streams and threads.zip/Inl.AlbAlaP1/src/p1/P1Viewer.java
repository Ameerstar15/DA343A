//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package p1;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class P1Viewer extends Viewer implements PropertyChangeListener {
    private MessageManager controller;

    public P1Viewer(MessageManager controller, int width, int height) {
        super(width, height);
        this.controller = controller;
        this.controller.addPropertyChangeListener(this);
    }

    public void propertyChange(PropertyChangeEvent evt) {
        this.setMessage((Message)evt.getNewValue());
    }
}
