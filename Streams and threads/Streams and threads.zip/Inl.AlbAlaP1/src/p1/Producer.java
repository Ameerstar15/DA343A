
/**
 *
 * @author Alameer Albadrani
 * *
 */

package p1;
import java.nio.file.LinkPermission;

/**
 * Producer has two buffers with a thread to do its work in this project
 */
public class Producer extends Thread
{
    private Buffer<MessageProducer> producerBuffer;
    private Buffer<Message> messageBuffer;

    /**
     * heres our constructor
     * @param producerBuffer
     * @param messageBuffer
     */
    public Producer(Buffer<MessageProducer> producerBuffer, Buffer<Message> messageBuffer)
    {
        this.messageBuffer = messageBuffer;
        this.producerBuffer = producerBuffer;
    }

    public synchronized void start()
    {
        super.start();
    }

    /**
     *
     * a run method that starts the function
     *
     */
    public  void run() {
        while (!Thread.interrupted()) {
            try {
                MessageProducer mp = (MessageProducer) this.producerBuffer.get();
                for (int i = 0; i < mp.times(); ++i) {
                    for (int j = 0; j < mp.size(); ++j) {
                        this.messageBuffer.put(mp.nextMessage());
                        sleep((long) mp.delay());

                    }
                }
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
    }
}
