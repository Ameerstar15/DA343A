package p2;


import P1.Message;
import P1.Viewer;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class P2Viewer extends Viewer implements PropertyChangeListener {

    private MessageClient messageClient;

    public P2Viewer(MessageClient messageClient, int width, int height) {
        super(width, height);
        this.messageClient = messageClient;
        this.messageClient.addPropertyChangeListener(this);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {setMessage((Message) evt.getNewValue());
    }

}
