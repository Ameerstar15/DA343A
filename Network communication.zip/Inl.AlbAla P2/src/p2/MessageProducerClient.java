package p2;


import P1.MessageProducer;

import java.io.ObjectOutputStream;
import java.net.Socket;

public class MessageProducerClient{
    private String ip;
    private int port;

    public MessageProducerClient(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }


    public void send(MessageProducer producer){
            try {
                Socket socket = new Socket(ip, port);
                ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                oos.writeObject(producer);
                oos.flush();
                oos.close();
            } catch (Exception e){
                e.printStackTrace();
            }
    }


}
