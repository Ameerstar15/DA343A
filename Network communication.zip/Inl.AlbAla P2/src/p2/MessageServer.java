package p2;
/**
 *
 * @author Alameer Albadrani
 *
 * Program DT
 *
 * Date: 210322

 */
import P1.Message;
import P1.MessageManager;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Server class that implements callback to send the object
 */
public class MessageServer implements ICallBack{

    private MessageManager messageM;
    private int port;

    private ArrayList<ClientHandler> clients;
    private Thread server;

    public MessageServer(MessageManager messageM, int port) {
        this.messageM = messageM;
        this.port = port;
        messageM.addListener(this);
        clients = new ArrayList<>();
        server = new Connection(port);
    }

    /**
     * Get picture and text from Interface ICallBack(methodToCall)
     * @param message
     */
    @Override
    public void methodToCall(Message message) {
        for(ClientHandler clientHandler : clients){
            try{
                clientHandler.sendMessage(message);
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }


    /**
     * Connection takes care of connecting the clients
     */
    private class Connection extends Thread{
        private int port;

        public Connection(int port) {
            this.port = port;
            start();
        }

        /**
         * A run method for new connections
         */
        @Override
        public void run(){
            try(ServerSocket serverSocket = new ServerSocket(port)){
                System.out.println("Server started");
                while(true){
                    try{
                        Socket socket = serverSocket.accept();
                        ClientHandler clientHandler = new ClientHandler(socket);
                        clients.add(clientHandler);
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                }
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }


    /**
     * ClientHandler takes care of connecting individual clients
     */
    private class ClientHandler extends Thread{
        private Socket socket;
        private ObjectOutputStream oos;


        public ClientHandler(Socket socket) {
            this.socket = socket;
            start();
        }


        public void run(){
            try{
                oos = new ObjectOutputStream(socket.getOutputStream());
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        /**
         * It sends message to clients
         * @param message
         * @throws IOException
         */
        public void sendMessage(Message message) throws IOException{
          oos.writeObject(message);
          oos.flush();
        }
    }
}
