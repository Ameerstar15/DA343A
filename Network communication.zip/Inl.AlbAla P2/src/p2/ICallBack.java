package p2;

import P1.Message;

public interface ICallBack {
    void methodToCall(Message message);
}
