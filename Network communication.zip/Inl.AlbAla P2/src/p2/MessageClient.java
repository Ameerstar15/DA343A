package p2;

import P1.Message;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.ObjectInputStream;
import java.net.Socket;


/**
 * MessageClient, Make connection to MessageServer then send to P2 Viewer
 */
public class MessageClient {

    private final PropertyChangeSupport change = new PropertyChangeSupport(this);

    /**
     *
     * @param ip Ip-Address
     * @param port PortNr
     */
    public MessageClient(String ip, int port){
        new Connection(ip, port);
    }

    /**
     * PropertyChangeListner
     * @param listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        change.addPropertyChangeListener(listener);
    }

    /**
     * Inner class, sends message to P2Viewer by objectInputStream & firePropertyChangeListener
     *
     */
    private class Connection extends Thread{
        private String ip;
        private int port;
        private ObjectInputStream ois;

        /**
         *  Staring the connection
         * @param ip
         * @param port
         */
        public Connection(String ip, int port) {
            this.ip = ip;
            this.port = port;
            start();
        }

        /**
         * Reads object from socket, load it to Message, that P2viewer uses it
         */
        public void run(){
            try(Socket socket = new Socket(ip, port)){
                System.out.println("Client is running");
                ois = new ObjectInputStream(socket.getInputStream());
                try{
                    while(true){
                        Message message = (Message) ois.readObject(); // read input object to message
                        change.firePropertyChange("message", null, message);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            } catch (Exception e){
                e.printStackTrace();
            }

        }
    }


}
