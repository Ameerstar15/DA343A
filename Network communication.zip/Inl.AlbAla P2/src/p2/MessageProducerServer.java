package p2;

import P1.MessageProducer;
import P1.MessageProducerInput;

import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class MessageProducerServer {
    private Thread server;
    private MessageProducerInput messageProducerInput;

    public MessageProducerServer(MessageProducerInput messageProducerInput, int port) {
        this.messageProducerInput = messageProducerInput;
        server = new Connection(port);
    }


    public void startServer(){
        server.start();
    }

    private class Connection extends Thread{
        private int port;

        public Connection(int port) {
            this.port = port;
        }

        public void run(){
            try(ServerSocket serverSocket = new ServerSocket(port)){
                System.out.println("Server is running");
                while(true){
                    Socket socket = serverSocket.accept(); // accept Socket
                    ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                    MessageProducer ap = (MessageProducer) ois.readObject();
                    messageProducerInput.addMessageProducer(ap);
                    socket.close();
                }
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
