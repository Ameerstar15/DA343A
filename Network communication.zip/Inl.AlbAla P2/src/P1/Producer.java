package P1;

public class Producer{

    private Buffer<MessageProducer> producerBuffer;
    private Buffer<Message> messageBuffer;
    private Thread thread;

    public Producer(Buffer<MessageProducer> producerBuffer, Buffer<Message> messageBuffer) {
        this.producerBuffer = producerBuffer;
        this.messageBuffer = messageBuffer;
    }

    private class innerClass extends Thread{
        @Override
        public void run(){
            MessageProducer mp;
            while (true){
                try{
                    mp = producerBuffer.get();
                    int times = mp.times();
                    int size = mp.size();

                    for (int i = 0; i<times; i++){
                        for (int j = 0; j<size; j++){
                            messageBuffer.put(mp.nextMessage());
                            sleep(mp.delay());
                        }
                    }
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
    }

    public void start(){
        if(thread == null){
            thread = new innerClass();
            thread.start();
        }
    }
}
