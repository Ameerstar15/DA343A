package P1;

import p2.ICallBack;

public class P1Viewer extends Viewer implements ICallBack {
    public P1Viewer(MessageManager messageManager, int width, int height) {
        super(width, height);
        messageManager.addListener(this);
    }

    @Override
    public void methodToCall(Message message) {
       setMessage(message);
    }
}


