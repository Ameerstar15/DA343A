package P1;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class TextfileProducer implements MessageProducer{

    private int times;
    private int delay;
    private Message[] messages;
    private int currentIndex = -1;

    public TextfileProducer(String filename) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)))) {
            times = Integer.parseInt(br.readLine());
            delay = Integer.parseInt(br.readLine());
            int size = Integer.parseInt(br.readLine());

            messages = new Message[size];

            for (int i = 0; i < size; i++) {
                String str = br.readLine();
                ImageIcon icon = new ImageIcon(br.readLine());
                messages[i] = new Message(str, icon);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public int delay() {
        return 0;
    }

    @Override
    public int times() {
        return times;
    }

    @Override
    public int size() {
        return messages.length;
    }

    @Override
    public Message nextMessage() {
        if (size() == 0) {
            return null;
        } else {
            currentIndex = (currentIndex +1) % messages.length;
            return messages[currentIndex];
        }
    }
}