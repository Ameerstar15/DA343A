package P1;

import P1.Buffer;
import P1.Message;
import p2.ICallBack;

import java.util.ArrayList;

public class MessageManager {
    private Buffer<Message> messageBuffer;
    private ArrayList<ICallBack> arrayList;
    private Thread thread;

    public MessageManager(Buffer<Message> messageBuffer) {
        this.arrayList = new ArrayList<>();
        this.messageBuffer = messageBuffer;
    }

    public void addListener(ICallBack listener){ arrayList.add(listener);}


    private class innerClass extends Thread{
        public void run(){
            Message m;
            while (true){
                try{
                    m = messageBuffer.get();
                    for (ICallBack iCallBack : arrayList) {
                        iCallBack.methodToCall(m);
                    }
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
    }

    public void start(){
        if(thread == null){
            thread = new innerClass();
            thread.start();
        }
    }

}
